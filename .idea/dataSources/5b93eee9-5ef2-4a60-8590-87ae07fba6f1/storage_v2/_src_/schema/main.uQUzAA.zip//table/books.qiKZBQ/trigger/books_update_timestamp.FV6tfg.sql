CREATE TRIGGER books_update_timestamp 
        AFTER UPDATE ON books
        BEGIN
            UPDATE books SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

