CREATE TRIGGER members_update_timestamp
        AFTER UPDATE ON members
        BEGIN
            UPDATE members SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

